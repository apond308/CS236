#ifndef INTERPRETER_H
#define INTERPRETER_H


class Interpreter
{
public:


private:


};



#endif