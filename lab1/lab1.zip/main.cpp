#include "Scanner.h"


int main(int argc, char* argv[]){
    string filename = argv[1];
    Scanner scanner = Scanner(filename);
}