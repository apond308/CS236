#include "Parameter.h"

Parameter::Parameter(string value)
{
    this->value = value;
}