#ifndef TUPLE_H
#define TUPLE_H

using namespace std;
#include <vector>
#include <string>

class Tuple : public vector<string>
{
public:

    void addElement(string to_add);


private:
    

};


#endif