#ifndef SCHEME_H
#define SCHEME_H

using namespace std;
#include <string>
#include <vector>

class Scheme : public vector<string>
{
private:

public:

};



#endif