#include "Tuple.h"

void Tuple::addElement(string to_add)
{
    this->push_back(to_add);
}
