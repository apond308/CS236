#ifndef DATALOGPROGRAM_H
#define DATALOGPROGRAM_H

#include <string>

class DatalogProgram
{
public:

    std::string toString();
};

#endif